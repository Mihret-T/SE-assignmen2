	A denial of service (DoS) attack is an attack to make a service unavailable to users by exhausting resources for the service. 
Application Attacks are one type of Dos Attack.HTTp fllod and slowloris is includes as an example of application based attacks.
Http fllod attack can be further subdivided into HTTP GET ATTACK AND HTTP POST ATTACK.
Dos attacks require a large number of get requests to be sent over a short period of time.i.e sending one get request to the target site every milliseconds.

From the two types of http flood attacks Get attacks are prefferes since they are easier to implement.